import users from "./data.js";

let total = document.getElementById("total");
let totalUsers = Object.keys(users).length;
console.log(totalUsers);
total.innerHTML += totalUsers;

let ul_page = document.getElementById("ul_element");

console.log(users[0]);
let pageIndex = 0;
let itemsPPage = 10;

paginationItems();
function paginationItems() {
    ul_page.innerHTML ="";
  for (
    let i = pageIndex * itemsPPage;
    i < pageIndex * itemsPPage + itemsPPage;
    i++
  ) {
    if (!users[i]) {
      break;
    }
    let emailArr = users[i].name.split(" ");
    let email = emailArr[0] + "." + emailArr[1] + "@example.com";
    console.log(email);
    let li = document.createElement("li");
    li.className = "contact-item cf";
    let div = document.createElement("div");
    div.className = "contact-details";
    let img = document.createElement("img");
    img.className = "avatar";
    img.src = users[i].image;
    let h3 = document.createElement("h3");
    h3.innerHTML = users[i].name;
    let span = document.createElement("span");
    span.className = "email";
    span.innerHTML = email;
    let div2 = document.createElement("div");
    div2.className = "joined-details";
    let span2 = document.createElement("span");
    span2.innerHTML = "Joined " + users[i].joined;

    div.appendChild(img);
    div.appendChild(h3);
    div.appendChild(span);

    div2.appendChild(span2);

    li.appendChild(div);
    li.appendChild(div2);
    ul_page.appendChild(li);
  }
}

let ul = document.getElementById("pagination");

for (let i = 0; i < totalUsers / itemsPPage; i++) {
  const li = document.createElement("li");
  li.innerHTML = i + 1;
  li.className="page-item";
  li.addEventListener("click", (e) => {
    pageIndex = e.target.innerHTML - 1;
    paginationItems();
  });

  ul.append(li);
}

// let paginations =document.getElementById("pagination");

// paginations.appendChild(document.createAttribute())
